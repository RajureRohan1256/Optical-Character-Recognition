# Restaurant Menu to XML > 2024-01-13 12:36am
https://universe.roboflow.com/restaurant-menu-image-to-xml/restaurant-menu-to-xml

Provided by a Roboflow user
License: CC BY 4.0

